-- AlterEnum
ALTER TYPE "Role" ADD VALUE 'SUPER_ADMIN';

