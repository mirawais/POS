-- AlterTable
ALTER TABLE "InvoiceSetting" ADD COLUMN     "tax_mode" TEXT NOT NULL DEFAULT 'EXCLUSIVE';
