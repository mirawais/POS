"use strict";(()=>{var e={};e.id=9454,e.ids=[9454],e.modules={72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},27790:e=>{e.exports=require("assert")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},17702:e=>{e.exports=require("events")},32615:e=>{e.exports=require("http")},35240:e=>{e.exports=require("https")},86624:e=>{e.exports=require("querystring")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},72068:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>h,patchFetch:()=>g,requestAsyncStorage:()=>m,routeModule:()=>c,serverHooks:()=>v,staticGenerationAsyncStorage:()=>x});var i={};r.r(i),r.d(i,{GET:()=>u,dynamic:()=>p});var s=r(49303),a=r(88716),n=r(60670),o=r(95456),d=r(20728),l=r(87070);let p="force-dynamic";async function u(e,{params:t}){try{let e=await (0,o.I8)(),r=e?.user;if(!r)return l.NextResponse.json({error:"Unauthorized"},{status:401});let i=r.clientId,s=t.id,a=await d._.sale.findUnique({where:{id:s},include:{cashier:{select:{id:!0,name:!0,email:!0}},items:{include:{product:{select:{id:!0,name:!0,sku:!0}},variant:{select:{id:!0,name:!0,sku:!0,attributes:!0}}}}}});if(!a||a.clientId!==i)return l.NextResponse.json({error:"Sale not found"},{status:404});let n=await d._.invoiceSetting.findUnique({where:{clientId:i}}),p=n?.logoUrl?`<img src="${n.logoUrl}" style="max-width:150px;" />`:"",u=n?.headerText?`<div>${n.headerText}</div>`:"",c=n?.footerText?`<div>${n.footerText}</div>`:"",m=a.items.map(e=>{let t=Number(e.price),r=Number(e.total);return`<tr><td>${e.product.name}${e.variant?` (${e.variant.name})`:""}</td><td>${e.quantity}</td><td>Rs. ${t.toFixed(2)}</td><td>Rs. ${r.toFixed(2)}</td></tr>`}).join(""),x=`
      <html>
        <head>
          <title>Order ${a.orderId}</title>
          <style>
            body { font-family: sans-serif; margin: 0; padding: 10px; }
            .invoice-header, .invoice-footer { text-align: center; margin-bottom: 10px; }
            .invoice-details { font-size: 12px; margin-bottom: 10px; }
            table { width: 100%; border-collapse: collapse; font-size: 12px; }
            th, td { border: 1px solid #eee; padding: 5px; text-align: left; }
            .totals { margin-top: 10px; font-size: 12px; text-align: right; }
            .totals div { display: flex; justify-content: space-between; }
            .totals strong { font-size: 14px; }
          </style>
        </head>
        <body>
          <div class="invoice-header">
            ${p}
            ${u}
          </div>
          <div class="invoice-details">
            Order ID: ${a.orderId}<br/>
            ${a.fbrInvoiceId?`FBR Invoice ID: ${a.fbrInvoiceId}<br/>`:""}
            Date: ${new Date(a.createdAt).toLocaleString()}<br/>
            ${n?.showCashier!==!1?`Cashier: ${a.cashier?.name||a.cashier?.email||"Unknown"}<br/>`:""}
            Payment Method: ${"CARD"===a.paymentMethod?"Card":"Cash"}<br/>
            ${n?.customFields&&Array.isArray(n.customFields)&&n.customFields.length>0?n.customFields.map(e=>`<div><strong>${e.label}:</strong> ${e.value}</div>`).join(""):""}
          </div>
          <table>
            <thead>
              <tr>
                <th>Item</th>
                <th>Qty</th>
                <th>Price</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>${m}</tbody>
          </table>
          <div class="totals">
            <div><span>Subtotal:</span><span>Rs. ${Number(a.subtotal).toFixed(2)}</span></div>
            ${n?.showDiscount!==!1&&Number(a.discount)>0?`<div><span>Discount:</span><span>-Rs. ${Number(a.discount).toFixed(2)}</span></div>`:""}
            ${n?.showTax!==!1&&Number(a.tax)>0?`<div><span>Tax:</span><span>Rs. ${Number(a.tax).toFixed(2)}</span></div>`:""}
            <div><strong><span>Total:</span><span>Rs. ${Number(a.total).toFixed(2)}</span></strong></div>
          </div>
          <div class="invoice-footer">
            ${c}
          </div>
        </body>
      </html>
    `;return l.NextResponse.json({html:x})}catch(e){return console.error("print GET error",e),l.NextResponse.json({error:e?.message??"Failed to fetch print data"},{status:500})}}let c=new s.AppRouteRouteModule({definition:{kind:a.x.APP_ROUTE,page:"/api/sales/[id]/print/route",pathname:"/api/sales/[id]/print",filename:"route",bundlePath:"app/api/sales/[id]/print/route"},resolvedPagePath:"C:\\Sample Project for cursor\\FirstProject\\app\\api\\sales\\[id]\\print\\route.ts",nextConfigOutput:"",userland:i}),{requestAsyncStorage:m,staticGenerationAsyncStorage:x,serverHooks:v}=c,h="/api/sales/[id]/print/route";function g(){return(0,n.patchFetch)({serverHooks:v,staticGenerationAsyncStorage:x})}},95456:(e,t,r)=>{r.d(t,{HT:()=>c,I8:()=>p,a4:()=>m});var i=r(75571),s=r.n(i),a=r(53797),n=r(20728),o=r(42023),d=r.n(o);let l={...process.env.NEXTAUTH_URL&&{baseUrl:process.env.NEXTAUTH_URL},session:{strategy:"jwt"},providers:[(0,a.Z)({name:"Credentials",credentials:{email:{label:"Email",type:"email"},password:{label:"Password",type:"password"}},authorize:async e=>{if(!e?.email||!e?.password)return null;let t=await n._.user.findUnique({where:{email:e.email}});return t&&await d().compare(e.password,t.password)?{id:t.id,email:t.email,name:t.name??void 0,role:t.role,clientId:t.clientId}:null}})],callbacks:{jwt:async({token:e,user:t})=>(t&&(e.id=t.id,e.role=String(t.role),e.clientId=t.clientId),e),session:async({session:e,token:t})=>(e.user.id=t.id,e.user.role=String(t.role),e.user.clientId=t.clientId,e)},pages:{signIn:"/login"}},p=()=>(0,i.getServerSession)(l),u=s()(l),c=u,m=u},20728:(e,t,r)=>{r.d(t,{_:()=>s});let i=require("@prisma/client"),s=globalThis.prisma??new i.PrismaClient({log:["error","warn"]})}};var t=require("../../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),i=t.X(0,[9276,3014,7070],()=>r(72068));module.exports=i})();