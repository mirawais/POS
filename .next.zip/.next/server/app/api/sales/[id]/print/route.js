"use strict";(()=>{var e={};e.id=9454,e.ids=[9454],e.modules={72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},27790:e=>{e.exports=require("assert")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},17702:e=>{e.exports=require("events")},32615:e=>{e.exports=require("http")},35240:e=>{e.exports=require("https")},86624:e=>{e.exports=require("querystring")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},72068:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>h,patchFetch:()=>g,requestAsyncStorage:()=>m,routeModule:()=>u,serverHooks:()=>x,staticGenerationAsyncStorage:()=>v});var i={};r.r(i),r.d(i,{GET:()=>p,dynamic:()=>c});var a=r(49303),s=r(88716),n=r(60670),o=r(95456),d=r(20728),l=r(87070);let c="force-dynamic";async function p(e,{params:t}){try{let e=await (0,o.I8)(),r=e?.user;if(!r)return l.NextResponse.json({error:"Unauthorized"},{status:401});let i=r.clientId,a=t.id,s=await d._.sale.findUnique({where:{id:a},include:{cashier:{select:{id:!0,name:!0,email:!0}},items:{include:{product:{select:{id:!0,name:!0,sku:!0}},variant:{select:{id:!0,name:!0,sku:!0,attributes:!0}}}}}});if(!s||s.clientId!==i)return l.NextResponse.json({error:"Sale not found"},{status:404});let n=await d._.invoiceSetting.findUnique({where:{clientId:i}}),c=n?.logoUrl?`<img src="${n.logoUrl}" style="max-width:150px;" />`:"",p=n?.headerText?`<div>${n.headerText}</div>`:"",u=n?.footerText?`<div>${n.footerText}</div>`:"",m=s.items.map(e=>{let t=Number(e.price),r=Number(e.total);return`<tr><td>${e.product.name}${e.variant?` (${e.variant.name})`:""}</td><td>${e.quantity}</td><td>Rs. ${t.toFixed(2)}</td><td>Rs. ${r.toFixed(2)}</td></tr>`}).join(""),v=`
      <html>
        <head>
          <title>Order ${s.orderId}</title>
          <style>
            body { font-family: sans-serif; margin: 0; padding: 10px; }
            .invoice-header, .invoice-footer { text-align: center; margin-bottom: 10px; }
            .invoice-details { font-size: 12px; margin-bottom: 10px; }
            table { width: 100%; border-collapse: collapse; font-size: 12px; }
            th, td { border: 1px solid #eee; padding: 5px; text-align: left; }
            .totals { margin-top: 10px; font-size: 12px; text-align: right; }
            .totals div { display: flex; justify-content: space-between; }
            .totals strong { font-size: 14px; }
          </style>
        </head>
        <body>
          <div class="invoice-header">
            ${c}
            ${p}
          </div>
          <div class="invoice-details">
            Order ID: ${s.orderId}<br/>
            ${s.fbrInvoiceId?`FBR Invoice ID: ${s.fbrInvoiceId}<br/>`:""}
            Date: ${new Date(s.createdAt).toLocaleString()}<br/>
            ${n?.showCashier!==!1?`Cashier: ${s.cashier?.name||s.cashier?.email||"Unknown"}<br/>`:""}
            Payment Method: ${"CARD"===s.paymentMethod?"Card":"Cash"}<br/>
            ${n?.customFields&&Array.isArray(n.customFields)&&n.customFields.length>0?n.customFields.map(e=>`<div><strong>${e.label}:</strong> ${e.value}</div>`).join(""):""}
          </div>
          <table>
            <thead>
              <tr>
                <th>Item</th>
                <th>Qty</th>
                <th>Price</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>${m}</tbody>
          </table>
          <div class="totals">
            <div><span>Subtotal:</span><span>Rs. ${Number(s.subtotal).toFixed(2)}</span></div>
            ${n?.showDiscount!==!1&&Number(s.discount)>0?`<div><span>Discount:</span><span>-Rs. ${Number(s.discount).toFixed(2)}</span></div>`:""}
            ${n?.showTax!==!1&&Number(s.tax)>0?`<div><span>Tax:</span><span>Rs. ${Number(s.tax).toFixed(2)}</span></div>`:""}
            <div><strong><span>Total:</span><span>Rs. ${Number(s.total).toFixed(2)}</span></strong></div>
          </div>
          <div class="invoice-footer">
            ${u}
          </div>
        </body>
      </html>
    `;return l.NextResponse.json({html:v})}catch(e){return console.error("print GET error",e),l.NextResponse.json({error:e?.message??"Failed to fetch print data"},{status:500})}}let u=new a.AppRouteRouteModule({definition:{kind:s.x.APP_ROUTE,page:"/api/sales/[id]/print/route",pathname:"/api/sales/[id]/print",filename:"route",bundlePath:"app/api/sales/[id]/print/route"},resolvedPagePath:"C:\\Sample Project for cursor\\FirstProject\\app\\api\\sales\\[id]\\print\\route.ts",nextConfigOutput:"",userland:i}),{requestAsyncStorage:m,staticGenerationAsyncStorage:v,serverHooks:x}=u,h="/api/sales/[id]/print/route";function g(){return(0,n.patchFetch)({serverHooks:x,staticGenerationAsyncStorage:v})}},95456:(e,t,r)=>{r.d(t,{HT:()=>u,I8:()=>c,a4:()=>m});var i=r(75571),a=r.n(i),s=r(53797),n=r(20728),o=r(42023),d=r.n(o);let l={...process.env.NEXTAUTH_URL&&{baseUrl:process.env.NEXTAUTH_URL},session:{strategy:"jwt"},providers:[(0,s.Z)({name:"Credentials",credentials:{email:{label:"Email",type:"email"},password:{label:"Password",type:"password"}},authorize:async e=>{if(!e?.email||!e?.password)return null;let t=await n._.user.findUnique({where:{email:e.email}});if(!t||!await d().compare(e.password,t.password))return null;if("SUPER_ADMIN"!==t.role&&t.clientId){let e=await n._.client.findUnique({where:{id:t.clientId},select:{isActive:!0,activeDate:!0,inactiveDate:!0}});if(e){let t=new Date,r=new Date(e.activeDate?e.activeDate:0),i=e.inactiveDate?new Date(e.inactiveDate):null;if(!e.isActive)throw Error("Your organization's account has been deactivated. Please contact support.");if(r>t)throw Error("Your organization's account is not yet active.");if(i&&i<t)throw Error("Your organization's account has expired. Please renew your subscription.")}}return{id:t.id,email:t.email,name:t.name??void 0,role:t.role,clientId:t.clientId}}})],callbacks:{jwt:async({token:e,user:t})=>(t&&(e.id=t.id,e.role=String(t.role),e.clientId=t.clientId),e),session:async({session:e,token:t})=>(e.user.id=t.id,e.user.role=String(t.role),e.user.clientId=t.clientId,e)},pages:{signIn:"/login"}},c=()=>(0,i.getServerSession)(l),p=a()(l),u=p,m=p},20728:(e,t,r)=>{r.d(t,{_:()=>a});let i=require("@prisma/client"),a=globalThis.prisma??new i.PrismaClient({log:["error","warn"]})}};var t=require("../../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),i=t.X(0,[9276,3014,7070],()=>r(72068));module.exports=i})();