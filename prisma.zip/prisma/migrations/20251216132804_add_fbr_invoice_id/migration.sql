-- AlterTable
ALTER TABLE "Sale" ADD COLUMN     "fbr_invoice_id" TEXT;
